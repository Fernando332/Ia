from typing import Literal


InputMode = Literal[
    "image",
    "video",
]
