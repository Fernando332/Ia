export const URLS = {
  "intro-to-video":
    "https://github.com/abi/screenshot-to-code/blob/main/blog/video-to-app.md",
};
